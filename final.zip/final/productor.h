#include<stdio.h>
#include<queue>
#include<thread>
#include<mutex>
#include<iostream>
#include<time.h>
#include<unistd.h>
#include<stdlib.h>
#include<condition_variable>
#include "monitor.h"

#ifndef PRODUCTOR_H
#define PRODUCTOR_H

using namespace std;

class Productor{
	private:
		Monitor* monitor;
		thread t;
		
		int Pro;
		
		void run_thread(){
			monitor->pro(Pro);
		}
	public:
		Productor (int nom, Monitor* mon){
		Pro = pro;
		monitor= mon,
		t= thread(&Productor::run_thread, this);
		}
		void join_thread () {
		t.join();
		}
	
		
};
#endif
