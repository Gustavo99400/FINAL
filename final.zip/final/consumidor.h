#include<stdio.h>
#include<queue>
#include<thread>
#include<mutex>
#include<iostream>
#include<time.h>
#include<unistd.h>
#include<stdlib.h>
#include<condition_variable>

#include "monitor.h"

using namespace std;



#ifndef CONSUMIDOR_H
#define CONSUMIDOR_H

class Consumidor{
	private:
	Monitor* monitor;
	thread t;
	int Con;
	void run_thread() {
		monitor -> con(Con);
	}
	public:
	
	Consumidor (int nom,Monitor* mon){
	Con = nom;
	monitor = mon;
	t = thread(&Consumidor::run_thread, this);
	}
	void join_thread () {
	t.join();
	
	}
};

#endif






