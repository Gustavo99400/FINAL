#include<stdio.h>
#include<queue>
#include<thread>
#include<mutex>
#include<iostream>
#include<time.h>
#include<unistd.h>
#include<stdlib.h>
#include<condition_variable>

#ifndef PRODUCTOR_H
#define PRODUCTOR_H

using namespace std;

class Monitor{
	private:
	
	int buffermax;
	bool bufferC = false;
	bool bufferP = true;
	queue <char> buffer;
	mutex flag;
	char letras[26] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
	
	condition_variable notEmpty, notFull;
	
	int item;	
	int items;
	
	
	public:
	Monitor(int full);
	void pro(int Pro);
	void con(int Con);	
	void printC (int pro, int cons);		
	};
	#endif


Monitor::Monitor(int full){

	buffermax = full;
	
}

void Monitor::pro (int Pro){

	for (int i = 1; true; i++){
	unique_lock<mutex> unique_lock(flag);
	
	if (buffer.size() == buffermax){
	bufferP = false;
	}
	
	notFull.wait(unique_lock, [this] (){
	
		cout << "----------------"<< endl;
		return bufferP != false;
	
	});
	
	int numRandom = rand() % 26;
	
	char letra = letras[numRandom];
	
	buffer.push(letra);	
	bufferC = true;
	
	printf ("(%d) Productor-%d estoy produciendo : %c \n", i, Pro, letra);
	cout << "\nTamaño de la cola " << buffer.size() << endl;
	item += 1;
	printC(item, items);
	
	bufferC = true;
	sleep(1);
	notEmpty.notify_one();
	}
}


void Monitor::con (int Con){

	for (int i = 1; true; i++){
		unique_lock<mutex> unique_lock(flag);
		
		if (buffer.size() == 0){
		bufferC = false;
	}
	
	notEmpty.wait(unique_lock, [this](){
		
		cout << "*******************" << endl;
		return bufferC != false;
	});
	
	printf ("(%d) Consumidor-%d estoy consumiendo : %c \n", i, Con,   	buffer.front());
	buffer.pop();
	cout << "Tamaño de la cola " << buffer.size() << endl;
	items += 1;
	printC(item, items);	
	bufferP = true;
	sleep(1);
	notFull.notify_one();
	}
}
void Monitor::printC (int pro, int cons){
	
	cout << " producido: " << pro << endl;
	cout << " consumido: " << cons << endl;
	
}





