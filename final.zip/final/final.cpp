#include<stdio.h>
#include<queue>
#include<thread>
#include<mutex>
#include<iostream>
#include<time.h>
#include<unistd.h>
#include<stdlib.h>
#include<condition_variable>

#include "consumidor.h"

#ifndef PRODUCTOR_H
#define PRODUCTOR_H

using namespace std;

class Productor{
	private:
		Monitor* monitor;
		thread t;
		
		int Pro;
		
		void run_thread(){
			monitor->pro(Pro);
		}
	public:
		Productor (int nom, Monitor* mon){
		Pro = pro;
		monitor= mon,
		t= thread(&Productor::run_thread, this);
		}
		void join_thread () {
		t.join();
		}
	
		
};
#endif

using namespace std;




int main(void) {
	
		
	int productoresN = 2;
	int consumidoresN = 2;
	
	int maxC = 5;
	Monitor mo(maxC);
	Monitor* monitor = & mo;
	
		
	Consumidor* consumidores[consumidoresN];
	Productor* productores[productoresN];
		
	int i;
	
	for (i=0; i < productoresN; i++){
	productores[i] = new Productor(i, monitor);
	}
	
	for (i=0; i < consumidoresN; i++){
	consumidores[i] = new Consumidor(i, monitor);
	}
	
	for (i=0; i < consumidoresN; i++){
	consumidores[i] -> join_thread();
	}
	
	for (i=0; i < productoresN; i++){
	productores[i] -> join_thread();
	}
	return 0;
}

	

	
	




